﻿using System;
using System.Collections.Generic;
using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.Data;

public partial class ShopContext : DbContext
{
    public ShopContext()
    {
    }

    public ShopContext(DbContextOptions<ShopContext> options)
        : base(options)
    {
    }

    public virtual DbSet<DeManufacturer> DeManufacturers { get; set; }

    public virtual DbSet<DeOrder> DeOrders { get; set; }

    public virtual DbSet<DeOrderList> DeOrderLists { get; set; }

    public virtual DbSet<DePickupPoint> DePickupPoints { get; set; }

    public virtual DbSet<DeProduct> DeProducts { get; set; }

    public virtual DbSet<DeRole> DeRoles { get; set; }

    public virtual DbSet<DeSupplier> DeSuppliers { get; set; }

    public virtual DbSet<DeUser> DeUsers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=mssql;Database=ispp2101;User Id=ispp2101;Password=2101;Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DeManufacturer>(entity =>
        {
            entity.HasKey(e => e.ManufacturerId);

            entity.ToTable("DE_Manufacturer");

            entity.Property(e => e.Name).HasMaxLength(15);
        });

        modelBuilder.Entity<DeOrder>(entity =>
        {
            entity.HasKey(e => e.OrderId);

            entity.ToTable("DE_Order");

            entity.Property(e => e.DeliveryDate).HasColumnType("datetime");
            entity.Property(e => e.OrderDate).HasColumnType("datetime");
            entity.Property(e => e.ReciveCode)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Status).HasMaxLength(10);

            entity.HasOne(d => d.PickupPoint).WithMany(p => p.DeOrders)
                .HasForeignKey(d => d.PickupPointId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DE_Order_DE_PickupPoint");

            entity.HasOne(d => d.User).WithMany(p => p.DeOrders)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DE_Order_DE_User");
        });

        modelBuilder.Entity<DeOrderList>(entity =>
        {
            entity.HasKey(e => new { e.OrderId, e.ProductId });

            entity.ToTable("DE_OrderList");

            entity.HasOne(d => d.Order).WithMany(p => p.DeOrderLists)
                .HasForeignKey(d => d.OrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DE_OrderList_DE_Order");

            entity.HasOne(d => d.Product).WithMany(p => p.DeOrderLists)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DE_OrderList_DE_Product");
        });

        modelBuilder.Entity<DePickupPoint>(entity =>
        {
            entity.HasKey(e => e.PickupPointId);

            entity.ToTable("DE_PickupPoint");

            entity.Property(e => e.City).HasMaxLength(25);
            entity.Property(e => e.Postcode)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Street).HasMaxLength(50);
        });

        modelBuilder.Entity<DeProduct>(entity =>
        {
            entity.HasKey(e => e.ProductId);

            entity.ToTable("DE_Product");

            entity.Property(e => e.Article)
                .HasMaxLength(6)
                .IsFixedLength();
            entity.Property(e => e.Category).HasMaxLength(15);
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.Name).HasMaxLength(15);
            entity.Property(e => e.Price).HasColumnType("decimal(10, 2)");

            entity.HasOne(d => d.Manufacturer).WithMany(p => p.DeProducts)
                .HasForeignKey(d => d.ManufacturerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DE_Product_DE_Manufacturer");

            entity.HasOne(d => d.Supplier).WithMany(p => p.DeProducts)
                .HasForeignKey(d => d.SupplierId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DE_Product_DE_Supplier");
        });

        modelBuilder.Entity<DeRole>(entity =>
        {
            entity.HasKey(e => e.RoleId);

            entity.ToTable("DE_Role");

            entity.Property(e => e.Name).HasMaxLength(25);
        });

        modelBuilder.Entity<DeSupplier>(entity =>
        {
            entity.HasKey(e => e.SupplierId);

            entity.ToTable("DE_Supplier");

            entity.Property(e => e.Name).HasMaxLength(15);
        });

        modelBuilder.Entity<DeUser>(entity =>
        {
            entity.HasKey(e => e.UserId);

            entity.ToTable("DE_User");

            entity.Property(e => e.Login).HasMaxLength(50);
            entity.Property(e => e.Name).HasMaxLength(25);
            entity.Property(e => e.Password)
                .HasMaxLength(6)
                .IsFixedLength();
            entity.Property(e => e.Patronymic).HasMaxLength(50);
            entity.Property(e => e.Surname).HasMaxLength(50);

            entity.HasOne(d => d.Role).WithMany(p => p.DeUsers)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DE_User_DE_Role");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
