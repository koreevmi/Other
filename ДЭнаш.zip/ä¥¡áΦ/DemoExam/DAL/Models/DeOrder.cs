﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class DeOrder
{
    public int OrderId { get; set; }

    public int UserId { get; set; }

    public int PickupPointId { get; set; }

    public DateTime OrderDate { get; set; }

    public DateTime DeliveryDate { get; set; }

    public string ReciveCode { get; set; } = null!;

    public string Status { get; set; } = null!;

    public virtual ICollection<DeOrderList> DeOrderLists { get; set; } = new List<DeOrderList>();

    public virtual DePickupPoint PickupPoint { get; set; } = null!;

    public virtual DeUser User { get; set; } = null!;
}
