﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class DeOrderList
{
    public int OrderId { get; set; }

    public int ProductId { get; set; }

    public byte Amount { get; set; }

    public virtual DeOrder Order { get; set; } = null!;

    public virtual DeProduct Product { get; set; } = null!;
}
