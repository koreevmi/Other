﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class DePickupPoint
{
    public int PickupPointId { get; set; }

    public string Postcode { get; set; } = null!;

    public string City { get; set; } = null!;

    public string Street { get; set; } = null!;

    public short Number { get; set; }

    public virtual ICollection<DeOrder> DeOrders { get; set; } = new List<DeOrder>();
}
