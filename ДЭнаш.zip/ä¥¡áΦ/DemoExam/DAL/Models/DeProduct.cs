﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class DeProduct
{
    public int ProductId { get; set; }

    public int ManufacturerId { get; set; }

    public int SupplierId { get; set; }

    public string Article { get; set; } = null!;

    public string Name { get; set; } = null!;

    public decimal Price { get; set; }

    public string Category { get; set; } = null!;

    public byte CurrentDiscount { get; set; }

    public byte QuantityInStock { get; set; }

    public string Description { get; set; } = null!;

    public virtual ICollection<DeOrderList> DeOrderLists { get; set; } = new List<DeOrderList>();

    public virtual DeManufacturer Manufacturer { get; set; } = null!;

    public virtual DeSupplier Supplier { get; set; } = null!;
}
