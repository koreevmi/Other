﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class DeRole
{
    public int RoleId { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<DeUser> DeUsers { get; set; } = new List<DeUser>();
}
