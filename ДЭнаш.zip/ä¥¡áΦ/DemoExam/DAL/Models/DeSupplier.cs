﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class DeSupplier
{
    public int SupplierId { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<DeProduct> DeProducts { get; set; } = new List<DeProduct>();
}
