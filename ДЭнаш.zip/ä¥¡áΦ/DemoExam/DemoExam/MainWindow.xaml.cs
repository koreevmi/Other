﻿using DAL.Data;
using DAL.Models;
using DemoExam.Windows;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExam
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string _userRole;
        private IQueryable<DeProduct> _products; // Для хранения текущего состояния фильтрации
        private LoginWindow _previousWindow;

        public MainWindow(string userName, string userRole, LoginWindow previousWindow)
        {
            InitializeComponent();
            lblTitle.Text = $"Главная - {userName} ({userRole})";
            _userRole = userRole;
            _previousWindow = previousWindow;

            if (_userRole == "Администратор")
            {
                adminPanel.Visibility = Visibility.Visible;
            }
        }

        private void LoadProducts()
        {
            try
            {
                using (var context = new ShopContext())
                {
                    _products = context.DeProducts.AsQueryable();
                    if (_products == null)
                    {
                        _products = new List<DeProduct>().AsQueryable(); // Инициализация пустой 
                    }
                    ApplyFilters();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке товаров: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilters()
        {
            try
            {
                if (_products == null)
                {
                    MessageBox.Show("Список товаров не загружен. Пожалуйста, попробуйте снова.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Поиск по тексту
                string searchText = txtSearch.Text.Trim();
                if (!string.IsNullOrEmpty(searchText))
                {
                    _products = _products.Where(p =>
                        p.Name.Contains(searchText) ||
                        p.Category.Contains(searchText) ||
                        p.Description.Contains(searchText)
                    );
                }

                // Фильтрация по поставщику
                string selectedSupplier = cmbSupplier.SelectedItem?.ToString();
                if (!string.IsNullOrEmpty(selectedSupplier) && selectedSupplier != "Все поставщики")
                {
                    _products = _products.Where(p => p.Supplier.Name == selectedSupplier);
                }

                // Сортировка
                string sortOption = cmbSort.SelectedItem?.ToString();
                if (sortOption == "По количеству (по возрастанию)")
                {
                    _products = _products.OrderBy(p => p.QuantityInStock);
                }
                else if (sortOption == "По количеству (по убыванию)")
                {
                    _products = _products.OrderByDescending(p => p.QuantityInStock);
                }

                // Обновление списка
                listViewProducts.ItemsSource = _products.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при фильтрации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void cmbSupplier_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void cmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void listViewProducts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listViewProducts.SelectedItem is DeProduct selectedProduct)
            {
                // Если администратор, разрешить редактирование
                if (_userRole == "Администратор")
                {
                    btnEditProduct_Click(sender, e);
                }
            }
        }

        private void btnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            if (_userRole == "Администратор")
            {
                ProductEditorWindow editorWindow = new ProductEditorWindow(null); // Открыть окно для добавления
                editorWindow.ShowDialog();
                LoadProducts(); // Обновить список после добавления
            }
            else
            {
                MessageBox.Show("У вас нет прав для добавления товаров.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void btnEditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (_userRole == "Администратор")
            {
                if (listViewProducts.SelectedItem is DeProduct selectedProduct)
                {
                    ProductEditorWindow editorWindow = new ProductEditorWindow(selectedProduct); // Открыть окно для редактирования
                    editorWindow.ShowDialog();
                    LoadProducts(); // Обновить список после редактирования
                }
                else
                {
                    MessageBox.Show("Выберите товар для редактирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("У вас нет прав для редактирования товаров.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void btnDeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (_userRole == "Администратор")
            {
                if (listViewProducts.SelectedItem is DeProduct selectedProduct)
                {
                    MessageBoxResult result = MessageBox.Show(
                        $"Вы уверены, что хотите удалить товар \"{selectedProduct.Name}\"?",
                        "Подтверждение удаления",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question
                    );

                    if (result == MessageBoxResult.Yes)
                    {
                        try
                        {
                            using (var context = new ShopContext())
                            {
                                // Проверка, используется ли товар в заказах
                                var orders = context.DeOrderLists
                                    .Where(o => o.ProductId == selectedProduct.ProductId)
                                    .ToList();

                                if (orders.Any())
                                {
                                    MessageBox.Show("Товар используется в заказах и не может быть удален.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                                    return;
                                }

                                // Удаление товара
                                context.DeProducts.Remove(selectedProduct);
                                context.SaveChanges();

                                MessageBox.Show("Товар успешно удален.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                                LoadProducts(); // Обновить список после удаления
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Ошибка при удалении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Выберите товар для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("У вас нет прав для удаления товаров.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            _previousWindow.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadProducts();
        }
    }
}