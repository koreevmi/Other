﻿using DAL.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DemoExam.Windows
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string username = txtUsername.Text;
                string password = txtPassword.Text;

                using (var context = new ShopContext())
                {
                    var user = context.DeUsers
                        .Include(u => u.Role)
                        .FirstOrDefault(u => u.Login == username && u.Password == password);

                    if (user != null)
                    {
                        MainWindow mainWindow = new MainWindow(user.Name, user.Role.Name, this);
                        mainWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show(
                            "Неверные учетные данные. Попробуйте снова.",
                            "Ошибка",
                            MessageBoxButton.OK,
                            MessageBoxImage.Error
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Ошибка при попытке авторизации: {ex.Message}",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }
        }

        private void btnGuest_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Гость", "Гость", this);
            mainWindow.Show();
            this.Close();
        }
    }
}
