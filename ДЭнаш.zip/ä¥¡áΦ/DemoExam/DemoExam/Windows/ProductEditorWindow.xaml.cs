﻿using DAL.Data;
using DAL.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using Path = System.IO.Path;


namespace DemoExam.Windows
{
    /// <summary>
    /// Логика взаимодействия для ProductEditorWindow.xaml
    /// </summary>
    public partial class ProductEditorWindow : Window
    {
        private DeProduct _product;
        private bool _isNewProduct;
        private static ProductEditorWindow _currentInstance; // Для отслеживания открытого окна

        public ProductEditorWindow(DeProduct product)
        {
            InitializeComponent();

            // Проверка на уникальность открытого окна
            if (_currentInstance != null)
            {
                MessageBox.Show("Невозможно открыть более одного окна редактирования товара.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                this.Close();
                return;
            }
            _currentInstance = this;

            if (product == null)
            {
                // Новый товар
                _isNewProduct = true;
                lblTitle.Text = "Добавление товара";
                LoadDefaultData();
            }
            else
            {
                // Редактирование существующего товара
                _isNewProduct = false;
                _product = product;
                lblTitle.Text = $"Редактирование товара: {product.Name}";
                LoadProductData(product);
            }
        }

        private void LoadDefaultData()
        {
            // Загрузка данных по умолчанию (например, списки категорий, производителей, поставщиков)
            using (var context = new ShopContext())
            {
                cmbManufacturer.ItemsSource = context.DeManufacturers.ToList();
                cmbSupplier.ItemsSource = context.DeSuppliers.ToList();
            }
        }

        private void LoadProductData(DeProduct product)
        {
            // Загрузка данных товара в поля
            txtName.Text = product.Name;
            txtDescription.Text = product.Description;
            cmbManufacturer.SelectedItem = product.Manufacturer;
            cmbSupplier.SelectedItem = product.Supplier;
            txtPrice.Text = product.Price.ToString();
            txtQuantity.Text = product.QuantityInStock.ToString();
            txtDiscount.Text = product.CurrentDiscount.ToString();

        }

        private void btnUploadImage_Click(object sender, RoutedEventArgs e)
        {
            // Логика загрузки изображения
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Изображения (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|Все файлы (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string imagePath = openFileDialog.FileName;
                imgProduct.Source = new BitmapImage(new Uri(imagePath));

                // Сохранение изображения в папку и обновление пути
                string relativePath = SaveImage(imagePath);
                txtImagePath.Text = relativePath;
            }
        }

        private string SaveImage(string imagePath)
        {
            
            string folderPath = "Images";
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            string fileName = $"product_{(_product?.ProductId ?? 0)}.jpg";
            string relativePath = Path.Combine(folderPath, fileName);
            string absolutePath = Path.Combine(Directory.GetCurrentDirectory(), relativePath);

            // Масштабирование изображения до 300x200 пикселей
            BitmapImage bitmap = new BitmapImage(new Uri(imagePath));
            BitmapImage resizedImage = ResizeImage(bitmap, 300, 200);

            // Сохранение изображения
            using (FileStream stream = new FileStream(absolutePath, FileMode.Create))
            {
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(resizedImage));
                encoder.Save(stream);
            }

            return relativePath;
        }

        private BitmapImage ResizeImage(BitmapImage image, int width, int height)
        {
            // Масштабирование изображения
            BitmapImage resizedImage = new BitmapImage();
            resizedImage.BeginInit();
            resizedImage.UriSource = image.UriSource;
            resizedImage.DecodePixelWidth = width;
            resizedImage.DecodePixelHeight = height;
            resizedImage.EndInit();
            return resizedImage;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверка данных
                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    MessageBox.Show("Наименование товара не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!decimal.TryParse(txtPrice.Text, out decimal price) || price < 0)
                {
                    MessageBox.Show("Цена должна быть положительным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity < 0)
                {
                    MessageBox.Show("Количество на складе должно быть положительным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!byte.TryParse(txtDiscount.Text, out byte discount))
                {
                    MessageBox.Show("Скидка должна быть числом от 0 до 100.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

               
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                // Освобождение статической переменной
                _currentInstance = null;
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
